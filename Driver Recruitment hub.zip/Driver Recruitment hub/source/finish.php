<!DOCTYPE html>
<html >
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>success</title>
<link rel="stylesheet" href="main.css" type="text/css" />
<style type="text/css">
#apDiv4 {
	position: absolute;
	left: 10px;
	top: 515px;
	width: 1320px;
	height: 283px;
	z-index: 6;
	background-position: center;
}
#apDiv9 {
	position: absolute;
	left: 503px;
	top: 214px;
	width: 312px;
	height: 300px;
	z-index: 7;
	background-image: url(019376-green-metallic-orb-icon-symbols-shapes-smiley-happy2.png);
	background-repeat: no-repeat;
	background-position: center center;
}
#apDiv4 h2 a {
	font-size: 22px;
	font-weight: 100;
	color: #FFA54A;
	text-decoration: none;
	text-transform: none;
}
#apDiv4 h2 a:hover {
	color: #FFFF9B;
	font-size: 22px;
	text-transform: none;
}
#apDiv4 h2 {
	font-size: 22px;
	color: seashell;
	font-family: Georgia, "Times New Roman", Times, serif;
	font-weight: 100;
	background-position: center top;
	background-repeat: no-repeat;
	text-align: center;
}

</style>
</head>
<body>
<div id="apDiv1"></div>
<div id="apDiv6"></div>
<div id="apDiv8"></div>
<div id="apDiv4"><h2>Congratulations!&nbsp;&nbsp;Your account has been successfully registered!</h2>


<h2>We have just sent a verification mail to your primary and secondary* mail addresses. Please confirm your identity.</h2> 
<h2><a href="login.php">Please login to enter the account.</a></h2>
</div>
<div id="apDiv9"></div>

</body>
</html>